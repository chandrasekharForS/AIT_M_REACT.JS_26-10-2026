import { useState } from "react";
import "./Calculator.css";

function Calculator() {
    const [num1, setNum1] = useState("");
    const [num2, setNum2] = useState("");
    const [result, setResult] = useState("");

    function handleNum1Change(e) {
        setNum1(e.target.value);
    }

    function handleNum2Change(e) {
         setNum2(e.target.value);
    }

    function handleAdd() {
        setResult(parseFloat(num1) + parseFloat(num2));
    }

    function handleSubtract() {
        setResult(parseFloat(num1) - parseFloat(num2));
    }

    function handleMultiply() {
        setResult(parseFloat(num1) * parseFloat(num2));
    }

    function handleDivide() {
        setResult(parseFloat(num1) / parseFloat(num2));
    }

    return (
        <div className="calculator">
            <h1>Calculator</h1>
            <input type="number" value={num1} onChange={handleNum1Change}></input>
            <input type="number" value={num2} onChange={handleNum2Change}></input>
            
            <div className="button-group">
                <button onClick={handleAdd}>+</button>
                <button onClick={handleSubtract}>-</button>
                <button onClick={handleMultiply}>*</button>
                <button onClick={handleDivide}>/</button>
            </div>
            
            <p className="result">Result: {result}</p>
        </div>
    );
}

export default Calculator;