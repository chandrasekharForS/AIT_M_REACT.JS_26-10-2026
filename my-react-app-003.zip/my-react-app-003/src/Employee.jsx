import "./Employee.css";

function Employee({name, designation, salary, location}) {
    return(
        <div className="employee-card">
            <h2>{name}</h2>
            <p><b>Designation:</b>{designation}</p>
            <p><b>Salary:</b>{salary}</p>
            <p><b>Location:</b>{location}</p>
        </div>
    )
};

export default Employee;