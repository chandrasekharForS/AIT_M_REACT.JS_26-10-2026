/*import Greetings from "./Greetings";

function App() {
  return(
    <Greetings 
      name="Divya" 
      age="22" 
      salary="900000.00"/>
  );
}

export default App;
*/

import Employee from "./Employee";
function App() {
  return(
    <div>
      <Employee
        name="Rahul" 
        designation="Java Developer"
        salary="900000.00"/>
      
      <Employee
        name="Priya" 
        designation="Python Developer"
        salary="1000000.00"/>

      <Employee
        name="Vikram" 
        designation="React Developer"
        salary="600000.00"/>
    </div>
  );
};

export default App;


