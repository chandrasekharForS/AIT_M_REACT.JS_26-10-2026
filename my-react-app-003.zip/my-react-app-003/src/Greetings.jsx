function Greetings({name, age, salary}) {
    return(
        <div>
            <h2>Welcome to {name}!</h2>
            <h3>Your age is {age}.</h3>
            <h4>Your salary is {salary}</h4>
        </div>
    )
};

export default Greetings;